package ir.manage.manageofusers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManageOfUsersApplication {

    public static void main(String[] args) {
        SpringApplication.run(ManageOfUsersApplication.class, args);
    }

}
