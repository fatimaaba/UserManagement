package ir.manage.manageofusers.exceptions;

public class DuplicateEmailException extends Throwable{
}
