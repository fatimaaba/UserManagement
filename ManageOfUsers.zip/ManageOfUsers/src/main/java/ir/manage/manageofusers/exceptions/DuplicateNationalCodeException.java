package ir.manage.manageofusers.exceptions;

/**
 * @author F_Babaei
 * @Date 12/13/2023
 */
public class DuplicateNationalCodeException extends Throwable{
}
