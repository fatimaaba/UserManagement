package ir.manage.manageofusers.exceptions;

public class EmailNotFoundException extends Throwable{
}
