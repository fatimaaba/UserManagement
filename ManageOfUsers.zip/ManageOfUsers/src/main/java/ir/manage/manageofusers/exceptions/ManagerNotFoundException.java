package ir.manage.manageofusers.exceptions;

public class ManagerNotFoundException extends Throwable{
    public ManagerNotFoundException(String manager_not_found) {

    }
}
