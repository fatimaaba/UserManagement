package ir.manage.manageofusers.exceptions;


public class UserNotFoundException extends Throwable{

    public UserNotFoundException(String s) {
    }
}
