alter table user_tbl
    add unique (national_code)